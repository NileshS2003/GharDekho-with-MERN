ip("shubham", "tere naam"); // User 1 listened to song 101
    musicGraph.addUserSongRelationship("ashok", "dil boya");    // User 2 listened to song 102
    musicGraph.addUserSongRelationship("shubham", "humma");